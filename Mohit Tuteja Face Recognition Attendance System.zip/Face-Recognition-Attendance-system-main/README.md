# Mohit Tuteja Face Recognition Attendance System
This system  Will able to perform  Mohit Tuteja Face Recognition Attendance System.


How to Run this project ------------------------------------------------------
Install  Pycharm /Python IDEL 3.9 
add library instructions ---------------
TECHNOLOGY USED:
1) tkinter for whole GUI
2) OpenCV for taking images and face recognition (cv2.face.LBPHFaceRecognizer_create())
3) CSV, Numpy, Pandas, datetime etc. for other purposes.
Install All the modules mentioned below 

pip install tk-tools,
pip install opencv-contrib-python,
pip install datetime,
pip install pytest-shutil,
pip install python-csv,
pip install numpy,
pip install pillow ,
pip install pandas,
pip install times,
