# Face-Recognition-Attendance-system
This system  Will able to perform  Face-Recognition-Attendance-system.

Facebook : https://www.facebook.com/www.mohammadbakir/
Contact-sayfshafi@gmail.com
How to Run this project ------------------------------------------------------
Install  Pycharm /Python IDEL 3.9 
add library instructions ---------------
TECHNOLOGY USED:
1) tkinter for whole GUI
2) OpenCV for taking images and face recognition (cv2.face.LBPHFaceRecognizer_create())
3) CSV, Numpy, Pandas, datetime etc. for other purposes.
Install All the modules mentioned below 

pip install tk-tools,
pip install opencv-contrib-python,
pip install datetime,
pip install pytest-shutil,
pip install python-csv,
pip install numpy,
pip install pillow ,
pip install pandas,
pip install times,
